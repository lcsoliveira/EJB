package br.com.dextra.treinamento.model.service.sessionbean;

import javax.ejb.Local;

@Local
public interface TestarStatelessLocal {
	
	Integer adicionar();

}
